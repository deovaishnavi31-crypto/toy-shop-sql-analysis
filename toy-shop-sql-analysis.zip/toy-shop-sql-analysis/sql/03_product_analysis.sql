-- Toy Shop Sales Analysis | Product Analysis

1. SELECT category, COUNT(*) AS total_products
FROM products GROUP BY category ORDER BY total_products DESC;

2. SELECT ROUND(AVG(unit_price),2) AS average_product_price
FROM products;

3. SELECT p.product_name,p.category,
       ROUND(SUM(oi.quantity*p.unit_price*(1-oi.discount_percent/100)),2) AS revenue
FROM orders o
JOIN order_items oi ON o.order_id=oi.order_id
JOIN products p ON oi.product_id=p.product_id
WHERE o.order_status='Completed'
GROUP BY p.product_name,p.category
ORDER BY revenue DESC LIMIT 10;

4. SELECT p.product_name,p.category,SUM(oi.quantity) AS units_sold
FROM orders o
JOIN order_items oi ON o.order_id=oi.order_id
JOIN products p ON oi.product_id=p.product_id
WHERE o.order_status='Completed'
GROUP BY p.product_name,p.category
ORDER BY units_sold DESC LIMIT 10;
