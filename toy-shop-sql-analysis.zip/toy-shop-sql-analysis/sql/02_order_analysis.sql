-- Toy Shop Sales Analysis | Order Analysis

1. SELECT COUNT(*) AS total_orders FROM orders;

2. SELECT order_status, COUNT(*) AS total_orders
FROM orders GROUP BY order_status ORDER BY total_orders DESC;

3. SELECT order_status, COUNT(*) AS total_orders,
       ROUND(COUNT(*)*100.0/SUM(COUNT(*)) OVER(),2) AS percentage
FROM orders GROUP BY order_status ORDER BY percentage DESC;

4. SELECT payment_method, COUNT(*) AS total_orders
FROM orders WHERE order_status='Completed'
GROUP BY payment_method ORDER BY total_orders DESC;

5. SELECT sales_channel, COUNT(*) AS total_orders
FROM orders WHERE order_status='Completed'
GROUP BY sales_channel ORDER BY total_orders DESC;
