-- Toy Shop Sales Analysis | Sales Analysis

1. SELECT ROUND(SUM(oi.quantity*p.unit_price*(1-oi.discount_percent/100)),2) AS total_revenue
FROM orders o JOIN order_items oi ON o.order_id=oi.order_id
JOIN products p ON oi.product_id=p.product_id
WHERE o.order_status='Completed';

2. SELECT DATE_TRUNC('month',o.order_date)::date AS month,
       ROUND(SUM(oi.quantity*p.unit_price*(1-oi.discount_percent/100)),2) AS monthly_revenue
FROM orders o JOIN order_items oi ON o.order_id=oi.order_id
JOIN products p ON oi.product_id=p.product_id
WHERE o.order_status='Completed'
GROUP BY DATE_TRUNC('month',o.order_date) ORDER BY month;

3. SELECT p.category,
       ROUND(SUM(oi.quantity*p.unit_price*(1-oi.discount_percent/100)),2) AS revenue
FROM orders o JOIN order_items oi ON o.order_id=oi.order_id
JOIN products p ON oi.product_id=p.product_id
WHERE o.order_status='Completed'
GROUP BY p.category ORDER BY revenue DESC;

4. SELECT o.sales_channel,COUNT(DISTINCT o.order_id) AS total_orders,
       ROUND(SUM(oi.quantity*p.unit_price*(1-oi.discount_percent/100)),2) AS revenue
FROM orders o JOIN order_items oi ON o.order_id=oi.order_id
JOIN products p ON oi.product_id=p.product_id
WHERE o.order_status='Completed'
GROUP BY o.sales_channel ORDER BY revenue DESC;

5. SELECT ROUND(SUM(oi.quantity*p.unit_price*(1-oi.discount_percent/100))
       /COUNT(DISTINCT o.order_id),2) AS average_order_value
FROM orders o JOIN order_items oi ON o.order_id=oi.order_id
JOIN products p ON oi.product_id=p.product_id
WHERE o.order_status='Completed';
