-- Toy Shop Sales Analysis | Customer Analysis

1. SELECT COUNT(*) AS total_customers FROM customers;

2. SELECT customer_type, COUNT(*) AS total_customers
FROM customers GROUP BY customer_type ORDER BY total_customers DESC;

3. SELECT city, COUNT(*) AS total_customers
FROM customers GROUP BY city ORDER BY total_customers DESC;

4. SELECT c.customer_id, c.customer_name, c.city,
       COUNT(DISTINCT o.order_id) AS total_orders,
       ROUND(SUM(oi.quantity*p.unit_price*(1-oi.discount_percent/100)),2) AS total_spent
FROM customers c
JOIN orders o ON c.customer_id=o.customer_id
JOIN order_items oi ON o.order_id=oi.order_id
JOIN products p ON oi.product_id=p.product_id
WHERE o.order_status='Completed'
GROUP BY c.customer_id,c.customer_name,c.city
ORDER BY total_spent DESC LIMIT 10;
